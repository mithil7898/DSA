#include<iostream>
#include<unordered_map>
using namespace std;

class books
{
    private:
        int id;
        string bookName;
        string auth;
        int last_pg_no;

    public:

        // books()
        // {
        //     id = -1;
        //     bookName = "No name";
        //     auth = "No name";   
        //     last_pg_no = 0;         
        // }

        books(){}

        books(int id, string bookName, string auth)
        {   
            this->id = id;
            this->bookName = bookName;
            this->auth = auth;
            last_pg_no = 0;
        }

        void turn_page()
        {
            last_pg_no++;
        }

        int display_cur_page()
        {
            return last_pg_no;
        }

        int getId()
        {
            return id;
        }

        string getBName()
        {
            return bookName;
        }

        string getAuth()
        {
            return auth;
        }
};

class library
{
    private:
        int size;
        int active_book_id;
        unordered_map<int, books> m;

    public:
        library()
        {
            active_book_id = 0;
            size = 0;
        }

        void addBook(int id, string bookName, string auth)
        {
            books b(id, bookName, auth);
            m[b.getId()] = b; 
            size++;
        }

        bool delBook(int id)
        {
            m.erase(id);
            size--;
            if(size < m.size())
            {   
                size++;
                return false;
            }
            else
            {
                if(id == active_book_id)
                {
                    active_book_id = 0;
                }
                return true;
            }
        }

        void displayLibrary()
        {
            for(auto i:m)
            {
                cout << i.first << ": " << i.second.getBName() << " by " << i.second.getAuth() << endl;
            }
            cout << endl;
        }

        bool readNewBook(int id)
        {
            int present = m.count(id);
            if(present)
            {
                active_book_id = id;
                cout << "Selected book is: " << m[active_book_id].getBName() << " by " << m[active_book_id].getAuth() << " ,Page no: " << m[active_book_id].display_cur_page() << endl;
                return true;
            }  
            else    
            {
                return false;
            }
                
        }

        bool readBook()
        {
            if(active_book_id == 0)
                return false;
            
            cout << "Currently reading: " << m[active_book_id].getBName() << " ,Page no: " << m[active_book_id].display_cur_page() << endl;
            return true;
        }

        void turn_page()
        {
            m[active_book_id].turn_page();
            cout << "Page turned" << endl;
        }
};


int main()
{
    library l;
    int choice = 0;
    int innerChoice = 0;
    int id;
    string bName;
    string authName;

    while(1)
    {
        cout << "1. Add New Book " << endl;
        cout << "2. Delete Book" << endl;
        cout << "3. Read New Book" << endl;
        cout << "4. Read Current Book" << endl;
        cout << "5. Display Library" << endl;
        cout << "0. Exit" << endl;
        
        cout << "Enter choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                
                cout << "Enter Book details: " << endl;
                cout << "Book ID: ";
                cin >> id;
                cin.ignore();
                cout << "Book Name: ";
                cin >> bName;
                cout << "Author Name: ";
                cin >> authName;
                l.addBook(id, bName, authName);
                cout << endl;
                break;

            case 2:

                cout << "Enter Book id to delete: " << endl;
                cin >> id;
                if(l.delBook(id))
                    cout << "Book deleted" << endl;
                else
                    cout << "Book with id: " << id << " is not present" << endl;
                
                cout << endl;
                break;

            case 3:

                l.displayLibrary();
                cout << "Select book id: " << endl;
                cin >> id;
                if(l.readNewBook(id))
                {
                    cout << "1. Turn Page" << endl;
                    cout << "0. Close Book" << endl;
                    while(1)
                    {
                        cout << "Enter inner choice: ";
                        cin >> innerChoice;
                        if(innerChoice == 1)
                            l.turn_page();
                        else
                            break;
                    }
                }
                else
                {
                    cout << "Book with id: " << id << " is not present" << endl;
                    break;
                }
                cout << endl;
                break;

            case 4:

                if(l.readBook())
                {
                    cout << "1. Turn Page" << endl;
                    cout << "0. Close Book" << endl;
                    while(1)
                    {
                        cout << "Enter inner choice: ";
                        cin >> innerChoice;
                        if(innerChoice == 1)
                            l.turn_page();
                        else
                            break;
                    }
                }
                else
                {
                    cout << "No book is being read currently" << endl;
                }
                cout << endl;
                break;
                
            case 5:

                l.displayLibrary();
                cout << endl;
                break;

            case -1:
                exit(0);

            default:
            cout << "Enter valid choice" << endl;
                break;
        }
    }

    //Book ID: 1
    // Book Name: Atomic_Habits
    // Author Name: James_Clear
    // Enter choice: 1
    // Enter Book details: 
    // Book ID: 2
    // Book Name: The_Mountain_is_You
    // Author Name: Brianna_Wiest
    // Enter choice: 1
    // Enter Book details: 
    // Book ID: 3
    // Book Name: Rich_Dad_Poor_Dad
    // Author Name: Robert_K


    return 0;
}