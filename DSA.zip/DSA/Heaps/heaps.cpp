#include<iostream>
#include<vector>
using namespace std;

class heap
{
    public:
        int arr[100];
        int size;

    
        heap()
        {
            arr[0] = -1;
            size = 0;
        }

        void insert(int val)
        {
            size = size + 1;
            int ind = size;
            arr[ind] = val;

            while(ind > 1)
            {
                if(arr[ind] > arr[ind/2])
                {
                    swap(arr[ind], arr[ind/2]);
                    ind = ind / 2;
                }
                else
                    return;
            }
        }

        void deleteRoot()
        {
            if(size == 0)
            {
                cout << "Nothing to delete" << endl;
                return;
            }

            arr[1] = arr[size];
            size --;

            int i = 1;

            while(i < size)
            {
                int leftInd = 2*i;
                int rightInd = 2*i + 1;

                if(leftInd < size && arr[i] < arr[leftInd])
                {
                    swap(arr[i], arr[leftInd]);
                    i = leftInd;
                }
                else if(rightInd < size && arr[i] < arr[rightInd])
                {
                    swap(arr[i], arr[rightInd]);
                    i = rightInd;
                }
                else
                    return;
            }
        }

        void correctPos(int arr[], int size, int ind)
        {
            if(size == 0)
            {
                cout << "Empty" << endl;
                return;
            }

            while(ind < size)
            {
                int leftInd = 2*ind;
                int rightInd = 2*ind + 1;

                if(leftInd < size && arr[ind] < arr[leftInd])
                {
                    swap(arr[ind], arr[leftInd]);
                    ind = leftInd;
                }
                else if(rightInd < size && arr[ind] < arr[rightInd])
                {
                    swap(arr[ind], arr[rightInd]);
                    ind = rightInd;
                }
                else
                    return;
            }
        }

        void heapify(int arr[], int size)
        {
            for(int i=size/2; i > 0; i--)
            {
                correctPos(arr, size, i);
            }
        }   

        void heapSort(int arr[], int size)
        {
            while(size > 0)
            {
                int i = 1;
                swap(arr[1], arr[size]);
                while(i < size)
                {
                    int leftInd = 2*i;
                    int rightInd = 2*i + 1;

                    if(leftInd < size && arr[i] < arr[leftInd])
                    {
                        swap(arr[i], arr[leftInd]);
                        i = leftInd;
                    }
                    else if(rightInd < size && arr[i] < arr[rightInd])
                    {
                        swap(arr[i], arr[rightInd]);
                        i = rightInd;
                    }
                    else
                        break;
                }
                size--;
            }
        }

        void print()
        {
            for(int i=1; i<=size; i++)
            {
                cout << arr[i] << " ";
            }
            cout << endl;
        }

        void print(int arr[], int size)
        {
            for(int i=1; i<=size; i++)
            {
                cout << arr[i] << " ";
            }
            cout << endl;
        }
};

int main()
{
    heap h;
    // h.insert(50);
    // h.insert(40);
    // h.insert(30);
    // h.insert(20);
    // h.insert(15);
    // h.print();
    // h.insert(70);
    // h.insert(40);
    // h.insert(50);
    // h.insert(15);
    // h.insert(30);
    // h.print();

    // h.deleteRoot();
    // h.print();

    int arr[] = {-1, 70, 60, 55, 45, 50};
    h.print(arr, 5);
    cout << endl;
    //h.heapify(arr, 5);
    h.heapSort(arr, 5);

    h.print(arr, 5);


    return 0;
}