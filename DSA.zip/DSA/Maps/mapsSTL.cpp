#include<iostream>
#include<unordered_map>
using namespace std;


int main()
{
    unordered_map<string, int> m;

    //insertion 

    //1

    pair<string, int> p1 = make_pair("mithil", 1);
    m.insert(p1);

    //2

    pair<string, int> p2("mithil", 2);
    m.insert(p2);

    //3

    m["bartakke"] = 3;

    //Searching & display its count

    cout << m["bartakke"] << endl;
    cout << m.at("bartakke") << endl;

    cout << m["pravinkumar"] << endl; // creates a new entry for unknown key corresponding to 0
    cout << m.at("pravinkumar") << endl;

    //To check presence
    cout << "To check presence: " << endl; 
    cout << m.count("mithil") << endl;

    //Erase

    m.erase("mithil");

    //Traverse

    //1

    for(auto i:m)
    {
        cout << i.first << " " << i.second << endl;
    }

    //2 Using Iterator

    unordered_map<string, int> :: iterator it = m.begin();

    while(it != m.end())
    {   
        cout << it->first << " " << it->second << endl;
        it++;
    }

    cout << "----------------------------------------------------------" << endl;


    // int id1 = 3;
    // int id2 = 4;
    // unordered_map<int, string> mp;
    // mp[1] = "mithil";
    // mp[2] = "pravinkumar";
    // mp[3] = "bartakke";


    // cout << mp[id1] << endl;
    // cout << mp[id2] << endl;



    return 0;
}