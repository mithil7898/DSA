#include<iostream>
using namespace std;

bool linearSearch(int arr[], int size, int n)
{
    if( size == 0)
        return false;

    if( arr[0] == n )
        return true;
        
    else
    {
        return linearSearch( arr + 1, size - 1, n);
    }
}

int main()
{   
    int arr[5] = {1, 2, 3, 4, 5};
    int size = 5;
    bool result = linearSearch(arr, size, 5);
    if(result)
        cout << "Element found" << endl;
    else
        cout << "Element not found" << endl;
        
    return 0;
}