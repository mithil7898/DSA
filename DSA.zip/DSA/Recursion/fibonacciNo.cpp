#include<iostream>
using namespace std;

int fib(int n)
{
    int ans;

    if(n == 0 || n == 1)
        return n;
    else
    {
        return (fib(n-1) + fib(n-2));
    }

    return ans;
}
int main()
{
    int n,i=0;
    cin >> n;
    while(i<n)
    {
        cout << " " << fib(i);
        i++;
    }

    return 0;
}