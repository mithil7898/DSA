#include<iostream>
#include<vector>
using namespace std;

void solve(vector<int> arr, vector<vector<int>> &ans, vector<int> output, int index)
{
    //base case
    if(index >= arr.size())
    {
        ans.push_back(output);
        return;
    }

    //exclude
    solve(arr, ans, output, index++);

    //include
    int element = arr[index];
    output.push_back(element);
    solve(arr, ans, output, index++);
}

vector<vector<int>> findSubsets(vector<vector<int>> &ans, vector<int> arr)
{
    vector<int> output;
    int index = 0;
    solve(arr, ans, output, index);
    return ans;
}


int main()
{
    vector<int> arr = {1, 2, 3};
    vector<vector<int>> ans;
    findSubsets(ans, arr);
    

    // vector<vector<int>> tmp = {{1}, {1, 3}};


    // for (int i = 0; i < 3; i++) 
    // {
    //     for (auto it = tmp[i].begin(); it != tmp[i].end(); it++)
    //     {
    //         cout << *it << " ";
    //     }
    //     cout << endl;
    // }
    // cout << endl;

    // cout << tmp.size();
    return 0;
}