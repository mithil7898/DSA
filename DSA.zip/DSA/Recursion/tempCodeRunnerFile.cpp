head = solve(head, head->next);
    // traverse(head);