#include<iostream>
using namespace std;

class Node
{
    public: 
        int data;
        Node *next;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
};

void insertAtEnd(Node* &head, int data)
{
    Node* temp = new Node(data);
    Node* ptr = head;

    if( ptr == NULL)
    {
        head = temp;
    }
    else
    {
        while( ptr->next != NULL)
        {
            ptr = ptr -> next;
        }

        ptr -> next = temp;
    }
}

void traverse(Node* &head)
{
    Node* ptr = head;

    if(ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        while( ptr != NULL)
        {
            cout << "Data is " << ptr->data << endl;
            ptr = ptr -> next;
        }
        cout << endl;
    }
}

Node* solve(Node *head, Node *node)
{
    while(node != NULL)
    {
        node->data = node->next->data;
        if(node->next->next == NULL)
        {
            Node *tmp = node->next;
            node->next = NULL;
            delete tmp;
            break;
        }
        node = node->next;
    }
    return head;
}

Node* remove(Node* head, int val)
{
    if(head == NULL)
    {
        return NULL;
    }
        
    if(head->next == NULL)
    {
        return head;
    }

    head->next = remove(head->next, val);
    if(head->data == val)
    {
        Node *tmp = head->next;
        head->next = NULL;
        delete head;
        return tmp;
    }
    else 
    {
    if(head->next->data == val)
        {
            Node *tmp = head->next;
            head = tmp->next;
            delete tmp;
            return head;
        }
        else
        {
            return head;
        }
    }
}

int main()
{
    Node *head = NULL;
    insertAtEnd(head, 4);
    insertAtEnd(head, 5);
    insertAtEnd(head, 1);
    insertAtEnd(head, 9);
    insertAtEnd(head, 5);
    traverse(head);
    // head = solve(head, head->next);
    head = remove(head, 5);
    traverse(head);
    return 0;
}