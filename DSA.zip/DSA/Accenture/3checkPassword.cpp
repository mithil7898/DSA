#include<iostream>
#include<string.h>
using namespace std;

int CheckPassword(char str[], int n)
{
    int no = 0;
    int cap = 0;
    if((str[0] >= 48 && str[0] <= 57) || n < 5)
        return 0;

    for(int i=1; i<n; i++)
    {
        if(str[i] == ' ' || str[i] == '/')
            return 0;
        else
        {
            if(no < 1)
            {
                if(str[i] >= 48 && str[i] <= 57)
                    no++;
            }
            else
            {
                if(cap < 1)
                {
                    if(str[i] >= 65 && str[i] <= 90)
                        cap++;
                }
            }
        }   
    }
    if(no >= 1 && cap >=1)
        return 1;
    return 0;
}


int main()
{
    char str[] = {'a', 'A', '1', '_', '6', '7'};
    int n = strlen(str);
    int ans = CheckPassword(str, n);
    cout << ans;
    return 0;
}