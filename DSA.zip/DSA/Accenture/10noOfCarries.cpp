#include<iostream>
using namespace std;

int noOfCarries(int n1, int n2)
{
    int noCarry = 0;
    int carryYes = 0;
    int r1, r2, sum;

    while(n1 != 0 || n2 != 0)
    {
        r1 = n1 % 10;
        r2 = n2 % 10;

        sum = r1 + r2 + carryYes;

        if(sum > 9)
        {
            noCarry++;
            carryYes = 1;
        }
        else
            carryYes = 0;

        n1 = n1 / 10;
        n2 = n2 / 10;
    }
    return noCarry;
}


int main()
{
    int num1 = 451;
    int num2 = 349;
    int ans = noOfCarries(num1, num2);
    cout << ans;
    return 0;
}