#include<iostream>
#include<math.h>
using namespace std;

int findCount(int arr[], int len, int num, int diff)
{
    int ele = -1;
    for(int i = 0; i<len; i++)
    {
        if(abs((arr[i]-num)) <= 2)
            ele++;
    }
    if(ele == -1)
        return ele;
    return ele + 1;
}

int main()
{
    int arr[] = {12, 3, 14, 56, 77, 13};
    int num = 13;
    int diff = 2;
    int ans = findCount(arr, 6, num, diff);
    cout << "ans: " << ans;
    return 0;
}