#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int sortArr(int *arr, int n)
{
    //sort arr into even and odd
    vector<int> evenArr;
    vector<int> oddArr;
    for(int i=0; i<n; i++)
    {
        if(i % 2 == 0)
        {
            evenArr.push_back(arr[i]);
        }
        else
            oddArr.push_back(arr[i]);
    }

    //sort into ascending order
    sort(evenArr.begin(), evenArr.end());
    sort(oddArr.begin(), oddArr.end());

    //find & add 2nd largest elements & return
    int evenSecSmall = evenArr[evenArr.size() - 2];
    int oddSecSmall = oddArr[oddArr.size() - 2];

    return (evenSecSmall + oddSecSmall);
}


int main()
{
    cout << "Enter size of array: ";
    int n;
    cin >> n;
    int *arr = new int[n];
    cout << "Enter elements: " << endl;
    for(int i=0; i<n; i++)
    {
        cin >> arr[i];
    }

    int ans = sortArr(arr, n);
    cout << ans;
    return 0;
}