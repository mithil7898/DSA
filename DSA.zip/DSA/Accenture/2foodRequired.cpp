#include<iostream>
using namespace std;

int foodReq(int r, int unit, int *arr, int n)
{
    if(n == 0) 
        return -1;
    
    int cnt = 0;
    int foodAvail = 0;
    int foodReq = r * unit;

    for(int i =0; i<n; i++)
    {
        if(foodAvail > foodReq)
            return cnt;
        
        foodAvail = foodAvail + arr[i];
        cnt++;
    }
}

int main()
{
    int arr[] = {2, 8, 3, 5, 7, 4, 1, 2};
    int r = 7;
    int unit = 2;
    int size = sizeof(arr)/sizeof(arr[0]);
    int ans = foodReq(r, unit, arr, size);
    cout << ans;
    return 0;
}