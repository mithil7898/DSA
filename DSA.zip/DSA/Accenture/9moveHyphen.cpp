#include <iostream>
#include <cstring>

using namespace std;

char* MoveHyphen(char str[], int n) {
    int hyphenCount = 0;
    for (int i = 0; i < n; ++i) {
        if (str[i] == '-')
            hyphenCount++;
    }

    int index = n;
    for (int i = n; i >= 0; i--) {
        if (str[i] != '-') {
            str[index] = str[i];
            index--;
        }
    }

    for (; index >= 0; index--) {
        str[index] = '-';
    }

    return str;
}

int main() {
    char input[] = "String-Compare";
    int length = strlen(input);

    cout << "Original String: " << input << endl;

    char* result = MoveHyphen(input, length);

    cout << "After moving hyphens to the front: " << result << endl;

    return 0;
}
