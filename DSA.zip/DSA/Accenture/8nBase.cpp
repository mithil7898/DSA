#include <iostream>
using namespace std;

char* nBase(int n, int num)
{
    int i = 0;
    int rem;
    char* str = new char[100]; // Allocate memory for the string

    while (num != 0)
    {
        rem = num % n;
        if (rem <= 9)
            str[i] = rem + 48;
        else
            str[i] = rem + 55;

        i++;
        num = num / n;
    }
    str[i] = '\0'; // Null-terminate the string
    return str;
}

int main()
{
    int n = 16;
    int num = 31;
    char* str = nBase(n, num);

    cout << "Number in base " << n << ": " << str << endl;

    delete[] str; // Deallocate memory

    return 0;
}
