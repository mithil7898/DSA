#include<iostream>
using namespace std;

int largeSmallSum(int arr[], int n)
{
    int fMax = INT8_MIN;
    int sMax = INT8_MIN;
    int fMin = INT8_MAX;
    int sMin = INT8_MAX;

    for(int i=0; i<n; i++)
    {
        if(i % 2 == 0)
        {
            if(arr[i] > fMax)
            {
                sMax = fMax;
                fMax = arr[i];
            }
            else if (arr[i] > sMax && arr[i] != fMax) 
            {
                sMax = arr[i];
            }
        }
        else
        {
            if(arr[i] < fMin)
            {
                sMin = fMin;
                fMin = arr[i];
            }
            else if (arr[i] < sMin && arr[i] != fMin) 
            {
                sMin = arr[i];
            }
        }
    }

    return (sMax + sMin);
}

int main()
{
    int arr[] = {3, 2, 1, 7, 5, 4};
    int n = sizeof(arr)/sizeof(arr[0]);
    int ans = largeSmallSum(arr, n);
    cout << ans;
    return 0;
}