#include<iostream>
#include<string.h>
using namespace std;

int OperationsBinaryString(char *str)
{
    if(strlen(str) == 0)
        return -1;
    
    int ans = int(str[0] - '0');

    for(int i=1; i<strlen(str); i = i+2)
    {
        char op = str[i];
        if(op == 'A')
            //ans = ans & int(str[i+1] - '0');
            ans = ans & int(str[i+1] - 48);
        else if (op == 'B')
            //ans = ans | int(str[i+1] - '0');
            ans = ans | int(str[i+1] - 48);
        else    
            //ans = ans ^ int(str[i+1] - '0');
            ans = ans ^ int(str[i+1] - 48);
    }
    return ans;
}

int main()
{
    char str[] = {'1', 'C', '0', 'C', '1', 'C', '1', 'A', '0', 'B', '1'};
    int ans = OperationsBinaryString(str);
    cout << "Ans: " << ans;
    return 0;
}