#include<iostream>
using namespace std;

int diffOfSum(int n, int m)
{
    int sumDiv = 0;
    int sumNotDiv = 0;
    for(int i = 1; i<=m; i++)
    {
        if((i % n) == 0)
            sumDiv = sumDiv + i;
        else
            sumNotDiv = sumNotDiv + i;
    }
    return abs((sumDiv-sumNotDiv));

}

int main()
{
    int n = 4;
    int m = 20;
    int ans = diffOfSum(n, m);
    cout << ans;
    return 0;
}