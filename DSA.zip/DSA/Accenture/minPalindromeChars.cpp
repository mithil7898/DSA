#include<iostream>
using namespace std;

char* findPalindromeChars(char str[], int n)
{
    int i=0, j=n-1;
    int firstCommonPos = 0;
    char *arr = new char[100];

    while(i <= j)
    {
        if(str[i] == str[j])
        {
            if(firstCommonPos != 0)
                firstCommonPos = i;
            j--;
        }   
        i++;
    }

    int ind = 0;
    for(int i=firstCommonPos; i>=0; i--)
    {
        arr[ind] = str[i];
        ind++;
    }

    return arr;
}

int main()
{
    char str[] = {'a', 'b', 'c', 'd', 'c'};
    int n = 5;

    char *ch = findPalindromeChars(str, n);
    for(int i=0; i<2; i++)
    {
        cout << ch[i];
    }
    return 0;
}