#include<iostream>
using namespace std;

int ProdSmallestPair(int arr[], int len, int sum)
{
    if(len == 0 || len < 2)
        return -1;
    
    int minInd = 0;
    for(int i=1; i<len; i++)
    {
        if(arr[i] < arr[minInd])
            minInd = i;
    }
    int n1 = arr[minInd];
    arr[minInd] = 9999999;
    minInd = 0;
    for(int i=1; i<len; i++)
    {
        if(arr[i] < arr[minInd])
            minInd = i;
    }
    int n2 = arr[minInd];
    if((n1 + n2) < sum)
        return n1*n2;
    return 0;
}

int main()
{
    int arr[] = {5, 2, 4, 3, 9, 7, 1};
    int len = 7;
    int sum = 9;
    int ans = ProdSmallestPair(arr, len, sum);
    cout << ans;
    return 0;
}