#include<iostream>
using namespace std;

void minMax(int *arr, int size)
{
    int tmp;
    int max = INT64_MIN;
    int min;

    for(int i=0; i<size ; i++)
    {
        tmp = 0;
        for(int j=0; j<size; j++)
        {
            tmp = tmp + arr[j];
        }
        tmp = tmp - arr[i];
        if(tmp > max)
        {
            max = tmp;
        }
    }
    cout << "Curr Max: " << max << endl;

    min = max;

    for(int i=0; i<size ; i++)
    {
        tmp = 0;
        for(int j=0; j<size; j++)
        {
            tmp = tmp + arr[j];
        }
        tmp = tmp - arr[i];
        if(tmp < min)
        {
            min = tmp;
        }
    }
    cout << "Curr Min: " << min << endl;
     
    
}


int main()
{
    int arr[5] = {1, 2, 3, 4, 5};
    minMax(arr, 5);
    return 0;
}