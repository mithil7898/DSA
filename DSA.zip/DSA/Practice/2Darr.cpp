#include <iostream>
using namespace std;

void binarySearch(int a[][3], int target, int row, int col)
{
    int s = 0;
    int e = row*col;
    int mid = s + (e-s)/2;

    int midElement = 
}

int main()
{   
    int arr[][3] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int target = 1;
    int row = 3;
    int col = 3;
    binarySearch(arr, target, row, col);

    return 0;
}