#include<iostream>
#include<string.h>
using namespace std;


int main()
{
    string s = "aaa01/01/2021";
    int len = s.length();
    cout << len;
    return 0;
}