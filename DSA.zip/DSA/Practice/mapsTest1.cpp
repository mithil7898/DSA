#include<iostream>
#include<unordered_map>
using namespace std;


int main()
{
    //int arr[5] = {10, 20, 30, 40, 50};
    int arr[] = {2, 12, 2, 11, -12, 2, -1, 2, 2, 11, 12, 2, -6};
    unordered_map<int, int> count;
    for(int i=0; i<13; i++)
    {
        count[arr[i]]++;
    }
    
    for(auto i:count)
    {
        cout << i.first << " " << i.second << endl;
    }
    
    return 0;
}