#include<iostream>
using namespace std;

class Node
{
    public:
    int data;
    Node *next;

    Node(int data)
    {
        this->data = data;
        next = NULL;
    }

};

void insertAtHead(Node* head)
{
    cout << "Add of head in insertAtHead: " << &head << endl;
}

void insertAtHead2(Node* &head)
{
    cout << "Add of head in insertAtHead2: " << &head << endl;
}

int main()
{
    Node *head = NULL;
    cout << "Add of head in main: " << &head << endl;
    insertAtHead(head);
    insertAtHead2(head);

    return 0;
}