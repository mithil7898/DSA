#include<iostream>
using namespace std;


int main()
{
    cout << 121%10 << endl;
    cout << 121/10 << endl;
    return 0;
}