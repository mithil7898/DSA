#include<iostream>
#include<String.h>
#include<unordered_map>
#include<map>
using namespace std;


int main()
{
    string s = "araaci";
    unordered_map<char, int> m;
    map<char, int> om;
    int max = 0;
    char frq;
    for(int i=0; i<s.length(); i++)
    {
        m[s[i]]++;
    }

    for(auto i:m)
    {
        if(i.second > max)
        {
            max = i.second;
            frq = i.first;
        }
    }

    cout << frq;

    
        
    return 0;
}