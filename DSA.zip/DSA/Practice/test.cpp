#include<iostream>
#include<unordered_map>
#include<String.h>
#include<map>
using namespace std;


int main()
{
    //unordered_map<char, int> m;

    //insert: 
    /*m['A']++;
    m['B']++;
    m['C']++;

    //print: 
    for(auto i:m)
        cout << i.first << ' ' << i.second << endl;


    //check presence: 
    cout << m['A'] << endl;
            //OR
    cout << m.count('A') << endl;*/
    // int maxLen = 0;

    // string s = "abcabcbb";

    // for(int i=0; i<s.length(); i++)
    // {
    //     if(s[i] != m.count(s[i]))
    //         m[s[i]]++;
    // }

    // for(auto i:m)
    //     cout << i.first << ' ' << endl;

    // cout << m.size() << endl;


    // map<char, int> m;
    // m['A'] = 1;
    // m['B'] = 2;
    // m['C'] = 3;

    // for(auto i:m)
    //     cout << i.first << ' ' << i.second << endl;

    // m.erase('A');
    // cout << endl;

    // for(auto i:m)
    //     cout << i.first << ' ' << i.second << endl;    
    
    // m['A'] = 1;
    // cout << endl;

    // for(auto i:m)
    //     cout << i.first << ' ' << i.second << endl;    

}