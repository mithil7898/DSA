#include<iostream>
#include <stack>

using namespace std;
int main()
{   
    stack<int> s;
    //s.push(1);

    cout << sizeof(s);
    return 0;
}