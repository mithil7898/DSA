#include<iostream>
using namespace std;

int num(int no)
{
    return no;
}

int main()
{
    bool ans = num(3) >= 1;
    cout << ans;
    return 0;
}