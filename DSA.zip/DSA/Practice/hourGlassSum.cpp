#include<iostream>
using namespace std;
int hourglassSum(int arr[100][100], int row, int col) 
{
    int tmpSum = 0;
    int sum = 0;
    int row = 0;
    int col = 0;
    int r, c;
    int count = 0;
    
    
        for(r=0; r<3; r++)
        {
            for(c=0; c<3; c++)
            {
                if(count==4 || count==6)
                {
                    count++;
                }
                else
                {
                    sum = sum + arr[r][c];
                    count++;
                }    
            }
        }       
    
    return sum;
}


int main()
{
    static int row;
    static int col;
    cin >> row;
    cin >> col;

    int arr[row][col];

    for(int i=0; i<row; i++)
    {
        for(int j=0; j<col; j++)
        {
            cin >> arr[row][col];
        }
        cout << endl;
    }

    int result = hourglassSum(arr, row, col);
    cout << result;
    return 0;
}