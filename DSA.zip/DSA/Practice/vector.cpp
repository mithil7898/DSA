#include<iostream>
#include<vector>
using namespace std;


int main()
{
    vector<int> no;
    no.push_back(1);
    no.push_back(2);

    for(int i=0; i<no.size(); i++)
    {
        cout << no[i] << " ";
    }
    return 0;
}