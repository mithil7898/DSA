#include<iostream>
using namespace std;


int main()
{
    string s = "Hello world";
    char ch;
    cout << ch << endl;
    int len = s.length();
    cout << len << endl;

    for(int i=0; i<len; i++)
    {
        cout << s[i] << " ";
    }
    cout << endl;
    return 0;
}