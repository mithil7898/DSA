#include<iostream>
#include<string>
using namespace std;


int main()
{
    string s1 = "Hello";
    string s2 = "el";

    s1.substr();

    return 0;
}