#include<iostream>
#include<vector>
using namespace std;
void print(vector<int> arr)
{
    for(int i=0; i<arr.size(); i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
void buildArr(vector<int> nums)
{
    vector<int> tmp;
    vector<int> ans;

    for(int i=0; i<nums.size(); i++)
    {
        tmp.push_back(nums[i]);
    }

    for(int i=0; i<nums.size(); i++)
    {
        ans.push_back(tmp[i]);
    }
    print(ans);
    
}




int main()
{
    vector<int> arr = {0, 2, 1};
    buildArr(arr);
    return 0;
}