#include<iostream>
using namespace std;

class abc
{
    public:

        int x;
        abc()
        {

        }

        void fun();
};


int main()
{
    void abc::fun()
    {
        cout << "FUN" << endl;
    }
    
    return 0;
}