#include<bits/stdc++.h>
using namespace std;

int main()
{
    //Enter data in vector
    // vector<int> arr2;
    // cout << "Enter data: ";
    // int data;
    // while(cin>>data)
    // {
    //     arr2.push_back(data);
    // }

    // for(auto it=arr2.begin(); it!=arr2.end(); it++)
    // {
    //     cout << *it << " ";
    // }

    //Enter data in 2d vector
    vector<vector<int>> arr;
    int data;
    char newRow;
    cout << "New Row?: 'Y' to enter"<<endl<<"'Any number' to exit";
    while(cin>>newRow)
    {
            cout << "Enter data into new row: " <<endl << "* ENTER ANY CHAR TO STOP THE INPUT *";
            vector<int> subAns;
            while(cin>>data)
            {
                subAns.push_back(data);
            }
            arr.push_back(subAns);
    }

    cout << endl;
    cout << arr.size() << endl;

}