#include<iostream>
using namespace std;


int main()
{
    cout << INT64_MAX << endl;
    return 0;
}