#include<iostream>
#include<vector>
using namespace std;


int main()
{
    vector<vector<int>> board;
    vector<int> v;
    int no;
    for(int i=0; i<9; i++)
    {
        for(int j=0; j<9; j++)
        {
            cout << "Enter no for " << i << "," << j <<": ";
            cin >> no;
            v.push_back(no);
        }
        board.push_back(v);
    }
    

    for(int i=0; i<board.size(); ++i)
    {
        for(int j=0; j<board[0].size(); ++j)
        {
            cout << board[i][j];
        }
        cout << endl;
    }

    return 0;
}


/*Conditions to satisfy SUDOKU solution:

- Each digit must occur exactly once in a row
- Each digit must occur exactly once in a column
- Each digit must occur exactly once in each of 3*3 sub-grids

STEPS TO SOLVE:
1. Iterate thru every cell
2. Check for empty cell (board[row][col] == 0)
3. If found - 
    - Check if its safe to put a value from (1-9) by calling isSafe(row, col, board, val)
    - put the val in the empty cell (board[row][col] = val)
    - RECURSIVE CALL for next empty cells (bool isPoss = solve(board))
    - if(isPoss) return true else return false
4. If iterated thru all cells with returning false, it means solution is possible, return true

bool isSafe(int row, int col, vector<vector<int>> &board, int val)
{
    1. check for row return 

    2. check for col return 

    3. check for 3*3 matrix - if(board[3*(row/3) + i/3][3*(col/3) + i%3] == val) return false
}
*/
