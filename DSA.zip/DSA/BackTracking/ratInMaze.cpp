#include<iostream>
#include<vector>
using namespace std;

bool isSafe(vector<vector<int>> m, int n, int x, int y, vector<vector<int>> visited)
{
    if((x>=0 && x<n) && (y>=0 && y<n) && (m[x][y] == 1) && (visited[x][y] == 0))
        return true;
    
    return false;
}

void solve(vector<vector<int>> m, int n, int x, int y, vector<vector<int>> visited,vector<string> &ans, string path)
{
    //base case
    if(x == n-1 && y == n-1)
    {
        ans.push_back(path);
        return;
    }

    visited[x][y] = 1;

    //call for down
    int newx = x+1;
    int newy = y;
    if(isSafe(m, n, newx, newy, visited))
    {
        path.push_back('D');
        solve(m, n, newx, newy, visited, ans, path);
        path.pop_back();
    }

    //call for left
    newx = x;
    newy = y-1;
    if(isSafe(m, n, newx, newy, visited))
    {
        path.push_back('L');
        solve(m, n, newx, newy, visited, ans, path);
        path.pop_back();
    }

    //call for right
    newx = x;
    newy = y+1;
    if(isSafe(m, n, newx, newy, visited))
    {
        path.push_back('R');
        solve(m, n, newx, newy, visited, ans, path);
        path.pop_back();
    }

    //call for up
    newx = x-1;
    newy = y;
    if(isSafe(m, n, newx, newy, visited))
    {
        path.push_back('U');
        solve(m, n, newx, newy, visited, ans, path);
        path.pop_back();
    }

    visited[x][y] = 0;
}

void findPath(vector<vector<int>> m, int n, vector<vector<int>> visited, vector<string> &ans)
{
    if(m[0][0] == 0)
        return;

    int srcx = 0;
    int srcy = 0;
    string path = "";

    solve(m, n, srcx, srcy, visited, ans, path);
}

int main()
{
    vector<vector<int>> m = {{1, 0, 0, 0}, {1, 1, 0, 1}, {1, 1, 0, 0}, {0, 1, 1, 1}};
    int n = 4;
    
    vector<vector<int>> visited;

    vector<int> tmp = {0, 0, 0, 0};

    for(int i=0; i<n; i++)
    {
        visited.push_back(tmp);
    }
        
    vector<string> ans;

    findPath(m, n, visited, ans);

    for(int i=0; i<ans.size(); i++)
    {
        cout << ans[i] << " ";
    }
        
    return 0;
}