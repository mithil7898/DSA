#include<iostream>
#include<vector>
using namespace std;

bool isSafe(int row, int col, vector<vector<int>> &board, int n)
{
    //not in same row
    int x = row;
    int y = col;
    while(y >= 0)
    {
        if(board[x][y] == 1)
            return false;

        y--;
    }

    //not in same col - no need to check cuz no two queens will be int the same col

    //not in same diagonal
    //1. Upper diag
    x = row;
    y = col;
    while(x >= 0 && y >= 0)
    {
        if(board[x][y] == 1)
            return false;

        y--;
        x--;
    }

    //2. Lower diag
    x = row;
    y = col;
    while(x < n && y >= 0)
    {
        if(board[x][y] == 1)
            return false;

        y--;
        x++;
    }

    return true;
}

//recursion
void solve(int col, vector<vector<int>> &ans, vector<vector<int>> &board, int n)
{
    //base case
    if(col == n)
    {
        //can be converted into addSol()
        vector<int> tmp;
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<n; j++)
            {
                tmp.push_back(board[i][j]);
            }
        }
        ans.push_back(tmp);
        return;
    }

    //solve for 1 case

    for(int row = 0; row<n; row++)
    {
        if(isSafe(row, col, board, n))
        {
            board[row][col] = 1;
            solve(col+1, ans, board, n);
            board[row][col] = 0;
        }
    }
}

void findSol(vector<vector<int>> &ans, int n)
{
    if(n == 0)
        return;
    
    vector<vector<int>> board(n, vector<int>(n, 0));
    //vector<vector<int>> board = { { 0, 0, 0, 0 },
						        //   { 0, 0, 0, 0 },
						        //   { 0, 0, 0, 0 },
						        //   { 0, 0, 0, 0 } };

    solve(0, ans, board, n);
    return;
}


int main()
{
    vector<vector<int>> ans;
    int n = 4;
    findSol(ans, n);

    for(int i=0; i<ans.size(); i++)
    {
        for(int j=0; j<ans[i].size(); j++)
        {
            cout << ans[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;

    
    return 0;
}