/*
    Return total number of subarrays whose sum = 7
*/

#include<bits/stdc++.h>
using namespace std;

void solve(int *nums, int sum, int size, vector<vector<int>> ans)
{
    int cursum = 0;
    int indexAtSumZero = -1;
    int ptr1 = -1;
    int ptr2 = 0;
    bool flag = false;

    while(ptr1 <= size)//for(int i=0; i<size; i++)
    {
        if(flag == true)
        {
            ptr1 = indexAtSumZero+1;
            flag = false;
        }
        else
        {
            ptr1++;
        }
        for(ptr2 = ptr1; ptr2<size; ptr2++)
        {
            cursum = cursum + nums[ptr2];
            //check is sum == 0, to mark that index from which we can get next sub-array 
            if(cursum == 0)
            {
                indexAtSumZero = ptr2;
                flag = true;
            }

            if((cursum - sum) == 0)
            {
                vector<int> subAns;
                for(int i=ptr1; i<=ptr2; i++)
                {
                    subAns.push_back(nums[i]);
                }
                ans.push_back(subAns);
            }
        }
    }

    cout << "Size: ";
    cout << ans.size() << endl; 

    cout << "Printing elements: " << endl;
    for(int i=0; i<ans.size(); i++)
    {
        for(auto it=ans[i].begin(); it != ans[i].end(); it++)
        {
            cout << *it << " ";
        }
        cout << endl;
    }
}

int main()
{
    int nums[] = {3, 4, -7, 1, 3, 3, 1, 4};
    int sum = 7;

    vector<vector<int>> ans;

    int size = sizeof(nums)/sizeof(nums[0]);
    //cout << size << endl;
    
    solve(nums, sum, size, ans);
    //cout << ans.size();


}

// #include<bits/stdc++.h>
// using namespace std;

// void solve(int *nums, int sum, int size, vector<vector<int>> &ans)
// {
//     int cursum = 0;
//     int indexAtSumZero = -1;
//     int ptr1 = 0;
//     int ptr2 = 0;
//     bool flag = false;

//     while(ptr1 <= size)//for(int i=0; i<size; i++)
//     {
//         if(flag == true)
//         {
//             ptr1 = indexAtSumZero+1;
//             flag = false;
//         }
//         ptr1++;
//         for(ptr2 = ptr1; ptr2<size; ptr2++)
//         {
//             cursum = cursum + nums[ptr2];
//             //check is sum == 0, to mark that index from which we can get next sub-array 
//             if(cursum == 0)
//             {
//                 indexAtSumZero = ptr2;
//                 flag = true;
//             }

//             if(cursum == sum)
//             {
//                 vector<int> subAns;
//                 for(int i=ptr1; i<=ptr2; i++)
//                 {
//                     subAns.push_back(nums[i]);
//                 }
//                 ans.push_back(subAns);
//                 cursum = 0;
//                 ptr1 = ptr2 + 1;
//             }
//             else if(cursum > sum)
//             {
//                 cursum = 0;
//                 ptr1 = ptr2 + 1;
//             }
//         }
//     }

//     cout << "Size: ";
//     cout << ans.size() << endl; 
// }

// int main()
// {
//     int nums[] = {3, 4, -7, 1, 3, 3, 1, 4};
//     int sum = 7;

//     vector<vector<int>> ans;

//     int size = sizeof(nums)/sizeof(nums[0]);
//     //cout << size << endl;
    
//     solve(nums, sum, size, ans);
//     cout << ans.size();
// }