// Reversing an array at specific index

#include <iostream>
using namespace std;

void reverseAtIndex(int a[], int n, int ind)
{
    int s = ind + 1;
    int e = n-1;
    int temp;

    while(s<=e)
    {
        swap(a[s], a[e]);
        s++;
        e--;
    }
}

void print(int a[], int n)
{
    for(int i=0; i<n; i++)
    {
        cout << a[i] << " ";
    }
}

int main()
{
    int arr[] = {1, 2, 3, 4, 8, 7, 6, 5};
    int n = 8;
    reverseAtIndex(arr, n, 3);
    cout << "Array after reversing ";
    print(arr, n);
    return 0;
}