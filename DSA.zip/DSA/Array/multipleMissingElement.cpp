#include <iostream>
using namespace std;

void findMulMissing(int a[], int size)
{
    int diff = a[0] - 0;
    int i;
    cout << "Missing elements are ";
    for(i=0; i<size; i++)
    {
        if(a[i] - i != diff)
        {
            while(diff < a[i] - i)
            {
                cout << diff + i << " ";
                diff++;
            }
        }
    }
}

int main()
{
    int arr[] = {1, 2, 3, 5, 6, 9};    
    findMulMissing(arr, 6);
    return 0;

}