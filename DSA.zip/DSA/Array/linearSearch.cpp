#include <iostream>
using namespace std;

bool search(int a[], int n, int key)
{
    for(int i=0; i<n; i++)
    {
        if(a[i] == key)
            return 1;
    }
    return 0;
}

int main()
{
    int a[10] = {1, 9, -6, 10, 78, 6, 21, 10, 3, 8};
    int key;
    cout << "Enter key to be searched" << endl;
    cin>>key;
    int found = search(a, 10, key);
    if(found)
    {
        cout << "Key found" << endl;
    }
    else
    {
        cout << "Key not found" << endl;
    }
    return 0;
}