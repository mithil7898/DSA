#include <iostream>
using namespace std;

void swap(int a[], int n)
{
    int p1 = 0;
    int p2 = 1;
    int s;
    while(p2 <= n)
    {
        s = a[p1];
        a[p1] = a[p2];
        a[p2] = s;
        p1 = p1 + 2;
        p2 = p2 + 2;
    }
    for(int i=0; i<n; i++)
    {
        cout << a[i] << endl;
    }
}

int main()
{
    int a[] = {1, 2, 3, 4, 5, 6};
    swap(a, 6);
    return 0;
}