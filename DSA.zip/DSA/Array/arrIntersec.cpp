#include <iostream>
using namespace std;

void findCommon(int a1[], int a2[], int n)
{
    int i, j, k=0;
    int c[6];
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
            {
                if(a1[i] == a2[j])
                {
                    c[k] = a2[j];
                    k++;
                }
            }
    }   
    for(i=0; i<k; i++)
    {
        cout << c[i] << endl;
    }
}

int main()
{
    int a1[] = {1, 2, 3, 4, 5, 6};
    int a2[] = {3, 4, 7, 8, 1, 2};
    findCommon(a1, a2, 6);
    return 0;
}