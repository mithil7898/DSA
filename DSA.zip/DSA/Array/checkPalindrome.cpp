#include <iostream>
using namespace std;

int palindrome(char ch[], int n)
{
    int s=0, e=n-1;
    while(s<=e)
    {
        if(ch[s] == ch[e])
        {
            s++;
            e--;
        }
        else
            return 0;
    }
    return 1;
}

int main()
{
    char ch[] = {'a', 'b', 'c', 'b', 'a'};
    int status = palindrome(ch, 6);
    if(status)
        cout << "yes" << endl;
    else
        cout << "no" << endl;
    return 0;
}