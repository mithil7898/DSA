#include <iostream>
using namespace std;

void findMissing(int a[], int h[], int low, int high, int n)
{   
    int i;
    for(i=0; i<n; i++)
    {
        h[a[i]] = 1;
    }

    cout << "Missing elements are ";
    for(i=low; i<=high; i++)
    {
        if(h[i] == 0)
        {
            cout << i << endl;
        }
    }
}

int main()
{
    int arr[] = {3, 7, 4, 9, 12, 6, 1, 11, 2, 10}; // unsorted array
    int H[12];
    for(int i=0; i<12; i++)
    {
        H[i] = 0;
    }

    findMissing(arr, H, 1, 12, 10);
    return 0;
}