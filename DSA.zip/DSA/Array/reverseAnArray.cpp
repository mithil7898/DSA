#include <iostream>
using namespace std;

void reverse(int a[], int n)
{
    int fp = 0;
    int lp = n-1;
    int s;
    while(fp<lp)
    {
        s = a[fp];
        a[fp] = a[lp];
        a[lp] = s;
        fp++;
        lp--;
    }
    for(int i=0; i<n; i++)
    {
        cout << a[i] << " ";
    }
}

int main()
{
    int a[] = {1, 2, 3, 4, 5};
    for(int i=0; i<5; i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;
    reverse(a, 5);
    return 0;
}