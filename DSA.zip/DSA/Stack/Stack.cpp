#include<iostream>
using namespace std;

class Stack
{
    public:
        int top;
        int *arr;
        int size;

        Stack(int size)
        {
            this->size = size;
            arr = new int[size];
            top = -1;
        }

        int isEmpty()
        {
            if(top == -1)
                return 1;
            else
                return 0;
        }

        int isFull()
        {
            if(top == size-1)
                return 1;
            else
                return 0;
        }

        void push(int data)
        {
            if(isFull())
            {
                cout << "Stack overflow" << endl;
                return;
            }
            else
            {
                top++;
                arr[top] = data;
                cout << "Done" << endl;
            }
        }

        int pop()
        {
            if(isEmpty())
            {
                cout << "Stack empty" << endl;
            }
            else
            {
                cout << "Values at position " << top << " is " << arr[top] << endl;
                top--;
            }
        }

        int peek()
        {
            if(isEmpty())
            {
                cout << "Stack empty" << endl;
            }
            else
            {
                cout << "Values at position " << top << " is " << arr[top] << endl;
            }
        }

};

int main()
{
    int size;
    cout << "Enter size of stack: ";
    cin >> size;
    Stack s(size);
    s.push(10);
    s.push(20);
    s.push(30);
    s.push(40);
    s.push(50);
    s.push(60);
    s.peek();
    s.peek();
    s.peek();
    s.pop();
    s.pop();
    s.pop();
    s.pop();
    s.pop();
    s.pop();
    return 0;
}