#include<iostream>
using namespace std;

class twoStack
{
    public:
        int top1;
        int top2;
        int n;
        int *arr;

        twoStack(int n)
        {
            this->n = n;
            arr = new int[n];
            top1 = -1;
            top2 = n;
        }

        void push1(int num)
        {
            if((top2 - top1) > 1)
            {
                top1++; 
                arr[top1] = num;
                cout << "Inserted" << endl;
            }
            else
            {
                cout << "Stack is full" << endl;
            }
        }

        void push2(int num)
        {
            if((top2 - top1) > 1)
            {
                top2--;
                arr[top2] = num;
                cout << "Inserted" << endl;
            }
            else
            {
                cout << "Stack is full" << endl;
            }
        }

        int pop1()
        {
            if(top1 >= 0)
            {
                int ans = arr[top1];
                top1--;
                return ans;
            }
            else
            {
                return -1;
            }
        }

        int pop2()
        {
            if(top2 < n)
            {
                int ans = arr[top2];
                top2++;
                return ans;
            }
            else
            {
                return -1;
            }
        }
};

int main()
{
    int size;
    cin >> size;
    int data;
    twoStack t(size);
 
    t.push1(10);
    t.push1(20);
    t.push1(30);
    t.push1(40);
    t.push2(50);
    cout << t.pop1() << endl;
    
    cout << t.pop1() << endl;
    // t.push2(60);

    return 0;
}