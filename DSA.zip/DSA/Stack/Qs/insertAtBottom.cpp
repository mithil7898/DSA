#include<iostream>
#include<stack>
using namespace std;

void pushAtEnd(stack<int> &s, int d)
{
    if(s.empty())
    {
        s.push(d);
        return;
    }

    int num = s.top();
    s.pop();
    pushAtEnd(s, d);
    s.push(num);

}


int main()
{
    stack<int> s;
    s.push(40);
    s.push(30);
    s.push(20);
    s.push(10);

    pushAtEnd(s, 50);

    cout << s.top() << endl;
    s.pop();

    cout << s.top() << endl;
    s.pop();

    cout << s.top() << endl;
    s.pop();

    cout << s.top() << endl;
    s.pop();

    cout << s.top() << endl;
    s.pop();

    cout << s.top() << endl;
    s.pop();

    return 0;
}