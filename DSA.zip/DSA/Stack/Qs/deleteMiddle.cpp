#include<iostream>
#include<stack>
using namespace std;

void solve(stack<int> &s, int N, int count)
{
    if(count == N/2)
    {
        s.pop();
        return;
    }

    int num = s.top();
    s.pop();
    solve(s, N, count+1);
    s.push(num);

}

void deleteMiddle(stack<int> &s, int N)
{
    int count = 0;
    solve(s, N, count);
} 

int main()
{
    stack<int> s;
    s.push(10);
    s.push(20);
    s.push(30);
    s.push(40);
    s.push(50);
    deleteMiddle(s, 5);

    cout << s.top() << endl;
    s.pop();

    cout << s.top() << endl;
    s.pop();

    cout << s.top() << endl;
    s.pop();

    cout << s.top() << endl;
    s.pop();



    return 0;
}