#include<iostream>
using namespace std;


int main()
{
    int size;
    cin >> size;

    int arr[size];

         
    return 0; 
}