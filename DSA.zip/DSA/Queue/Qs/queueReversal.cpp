#include<iostream>
#include<queue>
#include<stack>
using namespace std;

// void reverse(queue<int> q)
// {
//     stack<int> s;
    
//     while(!q.empty())
//     {
//         int val = q.front();
//         q.pop();
//         s.push(val);
//     }

//     while(!s.empty())
//     {
//         int val = s.top();
//         s.pop();
//         q.push(val);
//     }
// }

int main()
{
    queue<int> q;
    // queue<int> p;
    q.push(10);
    q.push(20);
    q.push(30);
    q.push(40);
    q.push(50);

    cout << q.front() << endl;
    q.pop();

    cout << q.front() << endl;
    q.pop();

    cout << q.front() << endl;
    q.pop();

    cout << q.front() << endl;
    q.pop();

    cout << q.front() << endl;
    q.pop();

    stack<int> s;
    queue<int> p;
    
    while(!q.empty())
    {
        int val = q.front();
        q.pop();
        s.push(val);
    }

    while(!s.empty())
    {
        int val = s.top();
        s.pop();
        p.push(val);
    }

    cout << "After: " << endl;

    cout << p.front() << endl;
    p.pop();

    cout << p.front() << endl;
    p.pop();

    cout << p.front() << endl;
    p.pop();

    cout << p.front() << endl;
    p.pop();

    cout << p.front() << endl;
    p.pop();
    return 0;
}