#include<iostream>
using namespace std;

class Queue
{
    private:
        int *arr;
        int front;
        int rear;
        int size;
    
    public:
        Queue(int size)
        {
            this->size = size;
            arr = new int[size];
            front = 0;
            rear = 0;
        }

        int isFull()
        {
           if(rear == size)
           {
                return 1;
           }
           else
           {
                return 0;
           }
        }

        int isEmpty()
        {
            if(front == rear)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        void enqueue(int data)
        {
           if(isFull())
           {
                cout << "Queue is full" << endl;
           }
           else
           {
                arr[rear] = data;
                rear++;
                cout << "Inserted" << endl;
           }
        }

        int dequeue()
        {
            int ans;
            if(isEmpty())
            {
                //cout << "Queue is empty" << endl;
                return -1;
            }
            else
            {
                ans = arr[front];
                front++;

                if(isEmpty())
                {
                    front = 0;
                    rear = 0;
                }
            }
            return ans;
        }

};


int main()
{
    Queue q(5);
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.enqueue(40);
    q.enqueue(50);
    q.enqueue(60);
    cout << q.dequeue() << endl;
    cout << q.dequeue() << endl;
    cout << q.dequeue() << endl;
    cout << q.dequeue() << endl;
    cout << q.dequeue() << endl;
    cout << q.dequeue() << endl;
    return 0;
}