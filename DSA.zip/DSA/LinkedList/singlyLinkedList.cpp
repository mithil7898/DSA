#include<iostream>
using namespace std;

class Node
{
    public: 
        int data;
        Node *next;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
};

void insertAtBeg(Node* &head, int data)
{
    Node * temp = new Node(data);

    if( head == NULL)
    {
        head = temp;
    }
    else
    {
        temp -> next = head;
        head = temp;
    }
}

void insertAtEnd(Node* &head, int data)
{
    Node* temp = new Node(data);
    Node* ptr = head;

    if( ptr == NULL)
    {
        head = temp;
    }
    else
    {
        while( ptr->next != NULL)
        {
            ptr = ptr -> next;
        }

        ptr -> next = temp;
    }
}

void insertAtPos(Node* &head, int pos, int data)
{
    int count = 1;
    Node *temp = new Node(data);
    Node *ptr = head;
    if(head == NULL)
    {
        head = temp;
    }
    else
    {
        while(count < pos - 1)
        {
            ptr = ptr -> next;
            count++;
        }
        temp -> next = ptr -> next;
        ptr -> next = temp;
    }

}

void deleteAtBeg(Node* &head)
{
    if(head == NULL)
    {   
        cout << "List empty" << endl;
    }
    else
    {
        Node* ptr = head;
        head = ptr -> next;
        delete ptr;
    }
}

void traverse(Node* &head)
{
    Node* ptr = head;

    if(ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        while( ptr != NULL)
        {
            cout << "Data is " << ptr->data << endl;
            ptr = ptr -> next;
        }
        cout << endl;
    }
}

void deleteAtEnd(Node* &head)
{
    Node* prev_ptr = head;
    
    if( prev_ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        Node* next_ptr = prev_ptr -> next;
        while( next_ptr -> next != NULL)
        {
            prev_ptr = next_ptr;
            next_ptr = next_ptr -> next;
        }
        prev_ptr -> next = NULL;
        delete(next_ptr);
    
    }
}

void deleteAtPos(Node* &head, int pos)
{

}

int main()
{   
    int choice = 0;
    int data;
    Node *head = NULL;

    while(1)
    {
        cout<<"1.Insert At Beg"<<endl
            <<"2.Insert At End"<<endl
            <<"3.Insert At Position"<<endl
            <<"4.Traverse"<<endl
            <<"5.Delete at Beg"<<endl
            <<"6.Delete at End"<<endl
            <<"0.Exit"<<endl;

        cout << endl;
        cout << "Enter choice: " << endl;
        
        cin >> choice;
        switch (choice)
        {
            case 1:
                cout << "Enter data: " << endl;
                cin >> data;
                insertAtBeg(head, data);
                cout << endl;
                break;
    
            case 2:
                cout << "Enter data: " << endl;
                cin >> data;
                insertAtEnd(head, data);
                cout << endl;
                break;
                
            case 3:
                int pos;
                cout << "Enter position: " << endl;
                cin >> pos;
                cout << "Enter data" << endl;
                cin >> data;
                insertAtPos(head, pos, data);
                cout << endl;
                break;

            case 4:
                traverse(head);
                cout << endl;

            case 5:
                deleteAtBeg(head);
                


            case 6:
                deleteAtEnd(head);

            case 0:
                exit;

            default:
                break;
        }
    }
    return 0;
}