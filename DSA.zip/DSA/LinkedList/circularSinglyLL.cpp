#include<iostream>
using namespace std;

class Node
{
    public:
        int data;
        Node* next;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
};

void insertAtEnd(Node* &tail, int data)
{
    Node* temp = new Node(data);

    if( tail == NULL)
    {
        tail = temp;
        temp->next = temp;
    }
    else
    {
        
    }
}


int main()
{
    Node* tail = NULL;
    return 0;
}