#include<iostream>
using namespace std;

class Node
{
    public: 
        int data;
        Node* next;
        Node* prev;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
            this->prev = NULL;
        }
};

void insertAtBeg(Node* &head, int data)
{
    Node* temp = new Node(data);

    if( head == NULL)
    {
        head = temp;
    }
    else
    {
        temp->next = head;
        head->prev = temp;
        head = temp;
    }
}

void insertAtEnd(Node* &head, int data)
{
    Node* temp = new Node(data);
    Node* ptr = head;

    if( head == NULL)
    {
        head = temp;
    }
    else
    {
        while( ptr->next != NULL)
        {
            ptr = ptr->next;
        }
        ptr->next = temp;
        temp->prev = ptr;
    }
}

void traverse(Node* &head)
{
    Node* ptr = head;

    if( ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        while( ptr != NULL)
        {
            cout << ptr->data << " ";
            ptr = ptr->next;
        }
        cout << endl;
    }
}

int main()
{
    Node* head = NULL;

    insertAtBeg(head,10);
    insertAtBeg(head,5);
    insertAtEnd(head,20);
    traverse(head);
    return 0;
}