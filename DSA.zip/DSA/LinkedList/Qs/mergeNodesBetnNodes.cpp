#include<iostream>
using namespace std;

class Node
{
    public: 
        int data;
        Node *next;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
};

void insertAtEnd(Node* &head, int data)
{
    Node* temp = new Node(data);
    Node* ptr = head;

    if( ptr == NULL)
    {
        head = temp;
    }
    else
    {
        while( ptr->next != NULL)
        {
            ptr = ptr -> next;
        }

        ptr -> next = temp;
    }
}

void traverse(Node* &head)
{
    Node* ptr = head;

    if(ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        while( ptr != NULL)
        {
            cout << "Data is " << ptr->data << endl;
            ptr = ptr -> next;
        }
        cout << endl;
    }
}



void mergeNodes(Node* &head)
{
    
    Node *cur = head;

}

int findSum(Node *tmp)
{
    int num = 0;
    while(tmp != NULL)
    {
        num = tmp->data + (num*10);
        tmp = tmp->next;
    }
    return num;
}

Node *solve(Node *l1, Node *l2)
{
    Node *ans = NULL;
    int num1 = findSum(l1);   
    int num2 = findSum(l2);
    cout << num1 << endl;
    cout << num2 << endl;

    int sum = num1 + num2;
    cout << sum << endl;
    if(sum == 0)
    {
        insertAtEnd(ans, sum);
    }
    else
    {
        while(sum > 0)
        {
            int rem = sum % 10;
            insertAtEnd(ans, rem);
            sum = sum / 10;
        }
    }

    return ans;
}

int main()
{
    // Node *head = NULL;
    // insertAtEnd(head, 0);
    // insertAtEnd(head, 3);
    // insertAtEnd(head, 1);
    // insertAtEnd(head, 0);
    // insertAtEnd(head, 4);
    // insertAtEnd(head, 5);
    // insertAtEnd(head, 2);
    // insertAtEnd(head, 0);
    // traverse(head);
    // // mergeNodes(head);
    // traverse(head);

    Node *l1 = NULL;
    insertAtEnd(l1, 7);
    insertAtEnd(l1, 4);
    insertAtEnd(l1, 9);
    traverse(l1);
    Node *l2 = NULL;
    insertAtEnd(l2, 5);
    insertAtEnd(l2, 6);
    insertAtEnd(l2, 4);
    insertAtEnd(l2, 9);
    traverse(l2);

    Node *ans = solve(l1, l2);
    traverse(ans);


}