#include<iostream>
using namespace std;

class Node
{
    public: 
        int data;
        Node *next;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
};

void insertAtEnd(Node* &head, int data)
{
    Node* temp = new Node(data);
    Node* ptr = head;

    if( ptr == NULL)
    {
        head = temp;
    }
    else
    {
        while( ptr->next != NULL)
        {
            ptr = ptr -> next;
        }

        ptr -> next = temp;
    }
}

void traverse(Node* &head)
{
    Node* ptr = head;

    if(ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        while( ptr != NULL)
        {
            cout << "Data is " << ptr->data << endl;
            ptr = ptr -> next;
        }
        cout << endl;
    }
}

void reverseLinkedList(Node* &head)
{
    Node* pp = NULL;
    Node* cp = head;
    Node* np = NULL;

    while(cp!=NULL)
    {
        np = cp->next;
        cp->next = pp;
        pp = cp;
        cp = np;
    }
    head = pp;
    //cout << pp << endl;
}

int main()
{
    Node *head = NULL;
    
    insertAtEnd(head,10);
    insertAtEnd(head,20);
    insertAtEnd(head,30);
    insertAtEnd(head,40);
    traverse(head);
    
    reverseLinkedList(head);
    traverse(head);
    cout << head << endl;
    return 0;
}