#include<iostream>
using namespace std;

class Node
{
    public: 
        int data;
        Node *next;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
};

void insertAtEnd(Node* &head, int data)
{
    Node* temp = new Node(data);
    Node* ptr = head;

    if( ptr == NULL)
    {
        head = temp;
    }
    else
    {
        while( ptr->next != NULL)
        {
            ptr = ptr -> next;
        }

        ptr -> next = temp;
    }
}

void traverse(Node* &head)
{
    Node* ptr = head;

    if(ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        while( ptr != NULL)
        {
            cout << "Data is " << ptr->data << endl;
            ptr = ptr -> next;
        }
        cout << endl;
    }
}

void removeDuplicates(Node* &head)
{
    if(head == NULL)
        return;
    
    Node *tmp = head;

    while(tmp->next != NULL)
    {
        if(tmp->next->data == tmp->data)
        {
            Node *deleteNode = tmp->next;
            tmp->next = deleteNode->next;
            delete deleteNode;
        }
        else
        {
            tmp = tmp->next;
        }
    }
}

int main()
{
    Node *head = NULL;
    insertAtEnd(head, 1);
    insertAtEnd(head, 2);
    insertAtEnd(head, 2);
    insertAtEnd(head, 2);
    insertAtEnd(head, 3);
    insertAtEnd(head, 3);
    insertAtEnd(head, 3);
    insertAtEnd(head, 4);
    traverse(head);
    removeDuplicates(head);
    traverse(head);

    return 0;
}