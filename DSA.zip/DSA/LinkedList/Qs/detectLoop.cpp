#include<iostream>
#include<map>

using namespace std;

class Node
{
    public: 
        int data;
        Node *next;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
};

void insertAtEnd(Node* &head, int data)
{
    Node* temp = new Node(data);
    Node* ptr = head;

    if( ptr == NULL)
    {
        head = temp;
    }
    else
    {
        while( ptr->next != NULL)
        {
            ptr = ptr -> next;
        }

        ptr -> next = temp;
    }
}

void traverse(Node* &head)
{
    Node* ptr = head;

    if(ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        while( ptr != NULL)
        {
            cout << "Data is " << ptr->data << endl;
            ptr = ptr -> next;
        }
        cout << endl;
    }
}

void createLoop(Node* &head)
{
    Node *tmp = head;

    while(tmp->next != NULL)
    {
        tmp = tmp->next;
    }

    tmp->next = head->next;
}

bool detectLoop(Node* &head)
{
    map<Node* , bool> visited;

    Node *tmp = head;

    while(tmp != NULL)
    {
        if(visited[tmp] == true)
        {
            return true;
        }
        
        visited[tmp] = true;
        tmp = tmp->next; 
    }
    return false;
}

int main()
{
    Node *head = NULL;

    insertAtEnd(head,10);
    insertAtEnd(head,20);
    insertAtEnd(head,30);
    insertAtEnd(head,40);
    traverse(head);
    createLoop(head);
    if(detectLoop(head))
    {
        cout << "Loop is present" << endl;
    }
    else
    {
        cout << "Loop not present" << endl;
    }

    return 0;
}