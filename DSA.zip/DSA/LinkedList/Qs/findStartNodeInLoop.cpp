#include<iostream>
using namespace std;

class Node
{
    public: 
        int data;
        Node *next;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
};

void insertAtEnd(Node* &head, int data)
{
    Node* temp = new Node(data);
    Node* ptr = head;

    if( ptr == NULL)
    {
        head = temp;
    }
    else
    {
        while( ptr->next != NULL)
        {
            ptr = ptr -> next;
        }

        ptr -> next = temp;
    }
}

void traverse(Node* &head)
{
    Node* ptr = head;

    if(ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        while( ptr != NULL)
        {
            cout << "Data is " << ptr->data << endl;
            ptr = ptr -> next;
        }
        cout << endl;
    }
}

void createLoop(Node* &head)
{
    Node *tmp = head;

    while(tmp->next != NULL)
    {
        tmp = tmp->next;
    }

    tmp->next = head->next;
}

Node* floyd(Node* &head)
{

    if(head == NULL)
        return NULL;

    Node *slow = head;
    Node *fast = head;

    while(slow != NULL && fast != NULL)
    {
        fast = fast->next;
        if(fast != NULL)
        {
            fast = fast->next;
        }
        slow = slow->next;

        if(slow == fast)
        {
            return slow;
        }
    }
    return NULL;
}

Node* findNode(Node *head)
{
    if(head == NULL)
        return NULL;
    
    Node *intersection = floyd(head);
    Node *slow = head;

    while(slow != intersection)
    {
        slow = slow->next;
        intersection = intersection->next;
    }
    return slow;
}

int main()
{
    Node *head = NULL;

    insertAtEnd(head,10);
    insertAtEnd(head,20);
    insertAtEnd(head,30);
    insertAtEnd(head,40);
    insertAtEnd(head, 50);
    insertAtEnd(head, 60);
    traverse(head);
    createLoop(head);
    // traverse(head);
    Node *ptr = findNode(head);
    if(ptr != NULL)
    {
        cout << "Starting node of the loop is: " << ptr->data << endl;
    }
    else    
        cout << "Loop is not present" << endl;

    return 0;
}