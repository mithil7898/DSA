#include<iostream>
using namespace std;

class Node
{
    public: 
        int data;
        Node *next;

        Node(int data)
        {
            this->data = data;
            this->next = NULL;
        }
};

void insertAtEnd(Node* &head, int data)
{
    Node* temp = new Node(data);
    Node* ptr = head;

    if( ptr == NULL)
    {
        head = temp;
    }
    else
    {
        while( ptr->next != NULL)
        {
            ptr = ptr -> next;
        }

        ptr -> next = temp;
    }
}

void traverse(Node* &head)
{
    Node* ptr = head;

    if(ptr == NULL)
    {
        cout << "List empty" << endl;
    }
    else
    {
        while( ptr != NULL)
        {
            cout << "Data is " << ptr->data << endl;
            ptr = ptr -> next;
        }
        cout << endl;
    }
}

Node* kReverseLinkedList(Node* &head, int k)
{
    //base case
    if(head == NULL)
        return head;

    int count = 0;
    Node *tmp = head;
    while(tmp!=NULL && count<k)
    {
        tmp = tmp->next;
        count++;
    }
    if(count<k)
    {
        return head;
    }

    Node* pp = NULL;
    Node* cp = head;
    Node* np = NULL;
    count = 0;

    while(cp!=NULL && count < k)
    {
        np = cp->next;
        cp->next = pp;
        pp = cp;
        cp = np;
        count++;
    }

    //recursion
    if(np!=NULL)
    {
        head->next = kReverseLinkedList(np,k);
    }
    return pp;
}

int main()
{
    Node *head = NULL;
    
    insertAtEnd(head,10);
    insertAtEnd(head,20);
    insertAtEnd(head,30);
    insertAtEnd(head,40);
    insertAtEnd(head,50);
    traverse(head);
    
    head = kReverseLinkedList(head,3);
    traverse(head);
    //cout << head << endl;
    return 0;
}