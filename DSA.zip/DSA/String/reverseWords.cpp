#include<iostream>
#include<vector>
using namespace std;

void reverseString(string s)
{
    cout << s << endl;
    vector<string> str;
    string tmp = "";

    for(int i=0; i < s.length(); i++)
    {
        if(s[i] == ' ')
        {
            str.push_back(tmp);
            tmp = "";
        }        
        else
        {
            tmp = tmp + s[i];
        }
    }
    // Last word remaining,add it to vector
    str.push_back(tmp);


    for(int i=str.size()-1;  i>0; i--)
    {
        cout << str[i] << " ";
    }
    // Last word remaining,print it
    cout << str[0];
    cout << endl;
}


int main()
{
    string s = "hello world";
    // int len = s.length();
    // cout << len << endl;
    // for(int i=0; i<len; i++)
    // {
    //     cout << s[i] << " ";
    // }
    reverseString(s);
    return 0;
}