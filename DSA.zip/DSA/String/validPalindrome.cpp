#include <iostream>
using namespace std;

bool valid(char c)
{
    if((c >= 'a' && c <= 'z') ||(c >= 'A' && c <= 'Z') ||(c >= '0' && c <= '9') )
    {
         return 1;
    }
    return 0;
}

char toLowerCase(char c)
{
    if( (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') )
    {
        return c;
    }
    else
    {
    char temp = c - 'A' + 'a';
    return temp;
    }
}

int palindrome(string str)
{
    int s=0, e=str.length() - 1;
    while(s<=e)
    {
        if(str[s] == str[e])
        {
            s++;
            e--;
        }
        else
            return 0;
    }
    return 1;
}
int main()
{   
    string s = "A man, a plan, a canal: Panama";

    //Remove unnecessary characters
    string temp = "";
    for(int i=0; i<s.length(); i++)
    {
        if(valid(s[i]))
        {
            temp.push_back(s[i]);
        }
    }

    //Characters to lower case
    for(int i=0; i<temp.length(); i++)
    {
        temp[i] = toLowerCase(temp[i]);
    }

    //Check Palindrome
    int status = palindrome(temp);
    if(status)
        cout << "True" << endl;
    else    
        cout << "False" << endl;

    return 0;
}