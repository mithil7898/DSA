 // for(int i=0; i<t; i++)
    // {
    //     for(int j=0; j<2; j++)
    //     {
    //         sum = arr[i][j];
    //         if(sum<3)
    //         {
    //             ans[i] = 1;
    //             break;
    //         }
    //         if(sum >= 3 && sum <= 10)
    //         {
    //             ans[i] = 2;
    //             break;
    //         }
    //         if(sum >= 11 && sum <= 60)
    //         {
    //             ans[i] = 3;
    //             break;
    //         }
    //         if(sum >= 60)
    //         {
    //             ans[i] = 4;
    //             break;
    //         }
    //     }
    // }