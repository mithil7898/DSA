#include <iostream>
#include <string>
using namespace std;

void selectionSort(int a[], int n)
{
    int minIndex, temp;
    int i,j;
    for(i=0; i < (n-1); i++)
    {
        minIndex = i;
        for(j=i+1; j<n; j++)
        {
            if(a[j] < a[minIndex])
            {
                minIndex = j;
            }
        }
        temp = a[minIndex];
        a[minIndex] = a[i];
        a[i] = temp;
    }
}

void printArray(int arr[], int size)
{
    int i;
    for (i=0; i < size; i++)
    {
      cout << arr[i] << endl;
    }
}

int main()
{
    int arr[] = {6, 2, 8, 4, 10};
    selectionSort(arr, 5);
    cout << "Sorted array is " << endl;
    printArray(arr, 5);
    return 0;
}