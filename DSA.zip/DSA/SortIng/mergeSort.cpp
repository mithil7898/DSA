#include<iostream>
using namespace std;

void merge(int *arr, int s, int m, int e)
{
    // find length of both arrays
    int len1 = m - s + 1;
    int len2 = e - m;

    // create two arrays
    int *arr1 = new int[len1];
    int *arr2 = new int[len2];

    // copy values
    int k = 0;
    for(int i=0; i<len1; i++)
    {
        arr1[i] = arr[k];
        k++;
    }

    k = m+1;
    for(int i=0; i<len2; i++)
    {
        arr2[i] = arr[k];
        k++;
    }

    //merge 2 sorted arrays

    int ind1 = 0;
    int ind2 = 0;
    k = s;

    while(ind1 < len1 && ind2 < len2)
    {
        if(arr1[ind1] < arr2[ind2])
        {
            arr[k] = arr1[ind1];
            ind1++;
        }
        else
        {
            arr[k] = arr2[ind2];
            ind2++;  
        }
        k++;
    }

    // remaining elements in arr1
    while(ind1 < len1)
    {
        arr[k] = arr1[ind1];
        ind1++;
        k++;
    }
    
    // remaining elements in arr2
    while(ind2 < len2)
    {
        arr[k] = arr2[len2];
        ind2++;
        k++;
    }
}

void mergeSort(int *arr, int s, int e)
{
    // base case
    if(s >= e)
    {
        return;
    }

    int m = s + (e-s)/2;
    mergeSort(arr, s, m);
    mergeSort(arr, m+1, e);
    merge(arr, s, m, e);
}

int main()
{
    int size;
    cout << "Enter size of array " << endl;
    cin >> size;
    int *arr = new int[size];
    cout << "Enter elements of array " << endl;
    for(int i=0; i<size; i++)
    {
        cin >> arr[i];
    }

    cout << "Array before sorting " << endl;
    for(int i=0; i<size; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    mergeSort(arr, 0, size-1);

    cout << "Sorted array is " << endl;
    for(int i=0; i<size; i++)
    {
        cout << arr[i] << " "; 
    }
    cout << endl;
    
    return 0;
}