# include <iostream>
using namespace std;

int main()
{
    int a, b;
    int t;
    cin>>t;
    int ans[t];
    int sum = 0;
    int arr[t][2];

    for(int i=0; i<t; i++)
    {
        for(int j=0; j<2; j++)
        {
            cin >> arr[i][j];
        }
    }

    for(int i=0; i<t; i++)
    {   
        sum = arr[i][0] + arr[i][1];
            if(sum<3)
            {
                ans[i] = 1;
                
            }
            else if(sum >= 3 && sum <= 10)
            {
                ans[i] = 2;
                
            }
            else if(sum >= 11 && sum <= 60)
            {
                ans[i] = 3;
                
            }
            else if(sum >= 60)
            {
                ans[i] = 4;
                
            }
    }

    for(int i=0; i<t; i++)
    {
        cout << ans[i] << endl;
    }

    return 0;
}