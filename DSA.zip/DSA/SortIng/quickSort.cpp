#include<iostream>
using namespace std;

int partition(int *arr, int s, int e)
{
    int pivot = arr[e];
    int i = s - 1; // indicates correct position of pivot

    for(int j=s; j<=e-1; j++)
    {
        if(arr[j] < pivot)
        {
            i++;
            swap(arr[i], arr[j]);
        }
    }

    swap(arr[i+1], arr[e]);

    return i+1;
}

void quickSort(int *arr, int s, int e)
{
    if(s < e)
    {
        int pi = partition(arr, s, e);
        quickSort(arr, s, pi-1);
        quickSort(arr, pi+1, e);
    }
}

int main()
{   
    cout << "Enter size of array " << endl;
    int n;
    cin >> n;
    int *arr = new int[n];

    cout << "Enter elements of array " << endl;
    for(int i=0; i<n; i++)
    {
        cin >> arr[i];
    }
    cout << endl;

    for(int i=0; i<n; i++)
    {
        cout << arr[i] << " ";
    } 
    cout << endl;

    quickSort(arr, 0, n-1);

    for(int i=0; i<n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}