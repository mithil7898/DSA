#include <iostream>
#include <string>
using namespace std;

void bubbleSort(int a[], int n)
{
    int temp;
    int max = 0;
    bool swapped = false;
    for(int i=0; i<n-1; i++)
    {
        for(int j=0; j<n-i; j++)
        {
            if(a[j] > a[j+1])
            {
                temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;   
     
            }
        }
    }
    max = a[n-1];
    cout << "Max: " << max << endl;
}

void printArray(int arr[], int size)
{
    int i;
    for (i=0; i < size; i++)
    {
      cout << arr[i] << endl;
    }
}

int main()
{
    int arr[] = {6, 2, 8, 10, 4};
    bubbleSort(arr, 5);
    cout << "Sorted array is " << endl;
    printArray(arr, 5);
    return 0;
}