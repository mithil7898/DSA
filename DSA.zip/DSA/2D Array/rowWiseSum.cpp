#include <iostream>
using namespace std;

void rowSum(int a[][3], int row, int col)
{
    for(row=0; row<3; row++)
    {
        int sum = 0;
        for(col=0; col<3; col++)
        {
            sum = sum + a[row][col];
        }
        cout << sum << endl;
    }
}

int main()
{
    int arr[][3] = {3, 4, 11, 2, 12, 1, 7, 8, 7};
    rowSum(arr, 3, 3);
    return 0;   
}