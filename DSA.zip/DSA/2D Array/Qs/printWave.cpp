#include<iostream>
using namespace std;

void printWave(int **arr, int size)
{
    int row = 0;
    int col = 0;

    while(col<size)
    {
        if( col%2 == 0 )
        {
            for(row = 0; row<size; row++)
            {
                cout << arr[row][col] << " ";
            }
        }
        else
        {
            for(row = size-1; row>=0; row--)
            {
                cout << arr[row][col] << " ";
            }
        }
        col++;

    }

    
}


int main()
{
    cout << "Enter size of matrix: ";
    int size;
    cin >> size;
    int **arr = new int* [size];

    for(int i=0; i<size; i++)
    {
        arr[i] = new int[size];
    }

    for(int i=0; i<size; i++)
    {
        for(int j=0; j<size; j++)
        {
            cin >> arr[i][j];
        }
    }    

    printWave(arr, size);

    return 0;
}