#include <iostream>
using namespace std;

int binarySearch2(int a[][3], int row, int col, int target)
{
    int rowIndex = 0;
    int colIndex = col - 1;

    while(rowIndex < row && colIndex >= 0)
    {
        int element = a[rowIndex][colIndex];
        if(element == target)
        {
            return 1;
        }
        if(element < target)
        {
            rowIndex++;
        }
        else
        {
            colIndex--;
        }
    }
    return 0;
}

int main()
{
    int arr[][3] = {{1, 4, 7,}, {2, 5, 8,}, {3, 6, 9,}};
    int status = binarySearch2(arr, 3, 3, 1);
    if(status)
        cout << "Element found" << endl;
    else
        cout << "Element not found" << endl;
    return 0;
}