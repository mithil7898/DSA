#include<iostream>
using namespace std;

int sqrt(int num)
{
    int s = 0;
    int e = num;
    int ans = -1;
    int mid = (s + e)/2;

    while(s<=e)
    {
        if((mid*mid) == num)
        {
            return mid;
        }
        else
        {
            if((mid*mid) > num)
                e = mid - 1; 
            else    
            {
                ans = mid;
                s = mid + 1;
            }   
        }
        mid = (s + e)/2;
    }
    return ans;
}

double morePrecision(int no, int precision, int tmpSol)
{
    double ans = tmpSol;
    double factor = 1;

    for(int i=0; i<precision; i++)
    {
        factor = factor / 10;

        for(double j=ans; j*j <= no; j = j+factor)
        {
            ans = j;
        }
    }
    return ans;
}

int main()
{
    cout << "Sqrt: " << sqrt(36) << endl;
    cout << "More precision: " << morePrecision(37, 3, 6);

    return 0;
}