#include<iostream>
using namespace std;

bool binarySearch(int *arr, int s, int e, int k)
{
    if(s > e)
        return false;

    int mid = s + (e-s)/2;
    if(k == arr[mid])
        return true;

    if(k > arr[mid])
        return binarySearch(arr, mid + 1, e, k);
    
    else
        return binarySearch(arr, s, mid - 1, k);

}

int findPivot(int *arr, int n)
{
    int s = 0;
    int e = n-1;
    int mid = 0;

    while(s<e)
    {
        mid = s + (e-s)/2;
        if(arr[mid] >= arr[0])
        {
            s = mid + 1;
        }
        else
        {
            e = mid;
        }
        mid = s + (e-s)/2;
    }
    return s; // can return e as both will point to same pos
}

int search(int *arr, int n, int key)
{
    int pivot = findPivot(arr, n);
    if(arr[pivot] <= arr[key] && key <= arr[n-1])
    {
        return binarySearch(arr, pivot, n-1, key);// for 2nd line
    }
    else
    {
        return binarySearch(arr, 0, pivot - 1, key);// for 1st line
    }
}

int main()
{   
    int arr[] = {7, 9, 1, 2, 3};
    int index = search(arr, 5, 7);
    if(index)
    {
        cout << "Element is present "<< endl;
    }
    else
    {
        cout << "Element is absent "<< endl;
    }
    
    return 0;
}