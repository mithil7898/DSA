#include<iostream>
using namespace std;

int findPivot(int *arr, int n)
{
    int s = 0;
    int e = n-1;
    int mid = 0;

    while(s<e)
    {
        mid = s + (e-s)/2;
        if(arr[mid] >= arr[0])
        {
            s = mid + 1;
        }
        else
        {
            e = mid;
        }
        mid = s + (e-s)/2;
    }
    return s; // can return e as both will point to same pos
}

int main()
{
    int arr[] = {7, 9, 1, 2, 3};
    int pivot = findPivot(arr, 5);
    cout << "Pivot element is present at index: "<< pivot << endl;
    return 0;
}