#include <iostream>
using namespace std;

int firstOcc(int a[], int n, int key)
{
    int s=0, e=n-1;
    int mid = s + (e-s)/2;
    int ans = -1;

    while(s <= e)
    {
        if(a[mid] == key)
        {
            ans = mid;
            e = mid - 1;
        }
        else if(key > a[mid])
        {
            s = mid + 1;
        }
        else
        {
            e = mid - 1;
        }

        mid = s + (e-s)/2;
    }
    return ans;
}

int lastOcc(int a[], int n, int key)
{
    int s=0, e=n-1;
    int mid = s + (e-s)/2;
    int ans = -1;

    while(s <= e)
    {
        if(a[mid] == key)
        {
            ans = mid;
            s = mid + 1;
        }
        else if(key > a[mid])
        {
            s = mid + 1;
        }
        else
        {
            e = mid - 1;
        }

        mid = s + (e-s)/2;
    }
    return ans;
}

int main()
{
    int arr[] = {1, 2, 3, 3, 3, 4, 5};
    int firstIndex = firstOcc(arr, 6, 3);
    int lastIndex = lastOcc(arr, 6, 3);

    cout << "First occ of 3 is at index " << firstOcc(arr, 5, 3) << endl;
    cout << "Lastt occ of 3 is at index " << lastOcc(arr, 5, 3);

    return 0;
}