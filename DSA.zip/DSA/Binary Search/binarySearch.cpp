#include <iostream>
using namespace std;

int binarySearch(int a[], int n, int key)
{
    int fp = 0;
    int lp = n-1;
    int mid = fp + (lp - fp)/2;

    while(fp <= lp)
    {
        if(key == a[mid])
        {
            return mid;
        }

        if(key > a[mid])
        {
            fp = mid + 1;
        }
        else
        {
            lp = mid - 1;
        }
        mid = fp + (lp - fp)/2;
    }
    return -1;
}

int main()
{
    int arr[] = {1, 2, 3, 4, 5, 6};
    int index = binarySearch(arr, 6, 4);

    cout << "Index of 4 is " << index;
    return 0;
}