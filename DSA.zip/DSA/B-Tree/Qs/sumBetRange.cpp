#include<iostream>
#include<queue>

using namespace std;

class Node
{
    public:
    int data;
    Node* left;
    Node* right;

    Node(int data)
    {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};

Node* buildTree(Node* root)
{
    cout << "Enter data: ";
    int data;
    cin >> data;

    if( data == -1 )
    {
        return NULL;
    }

    root = new Node(data);

    //Build left part
    cout << "Enter data for inserting in left of " << data << endl;
    root->left = buildTree(root->left);

    //Build right part
    cout << "Enter data for inserting in right of " << data << endl;
    root->right = buildTree(root->right);

    return root;

}

void levelOrderTraversal(Node *root)
{
    queue<Node*> q;
    q.push(root);

    while(!q.empty())
    {
        Node *tmp = q.front();
        cout << tmp->data << " ";
        q.pop();

        if(tmp->left)
        {
            q.push(tmp->left);
        }
        
        if(tmp->right)
        {
            q.push(tmp->right);
        }
    }
}

Node* findSum(Node* root, int low, int high, int &sum)
{
    
}

int rangeSum(Node* root, int low, int high)
{
    int sum = 0;
    findSum(root, low, high, sum);
    return sum;
}

int main()
{
    Node* root = NULL;
    //buildFromLvlorder(root);

    root = buildTree(root);

    cout << "lvlOrderTraversal: ";
    levelOrderTraversal(root);
    cout << endl;

    int sum = rangeSum(root, 7, 15);
    cout << "Sum: " << sum << endl;
    return 0;
}