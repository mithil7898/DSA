#include<iostream>
#include<queue>
#include<utility>

using namespace std;

class Node
{
    public:
    int data;
    Node* left;
    Node* right;

    Node(int data)
    {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};

Node* buildTree(Node* root)
{
    cout << "Enter data: ";
    int data;
    cin >> data;

    if( data == -1 )
    {
        return NULL;
    }

    root = new Node(data);

    //Build left part
    cout << "Enter data for inserting in left of " << data << endl;
    root->left = buildTree(root->left);

    //Build right part
    cout << "Enter data for inserting in right of " << data << endl;
    root->right = buildTree(root->right);

    return root;

}

void lvlOrderTraversal(Node *root)
{
    queue<Node*> q;
    q.push(root);

    while(!q.empty())
    {
        Node *tmp = q.front();
        cout << tmp->data << " ";
        q.pop();

        if(tmp->left)
        {
            q.push(tmp->left);
        }

        if(tmp->right)
        {
            q.push(tmp->right);
        }
    }
}

pair<int, int> diameterFast(Node* root)
{
    if(root == NULL)
    {
        pair<int, int> p = make_pair(0,0);
        return p;
    }
    pair<int, int> left = diameterFast(root->left);
    pair<int, int> right = diameterFast(root->right);

    int opt1 = left.first;
    int opt2 = right.first;
    int opt3 = left.second + right.second + 1;

    pair<int, int> ans;
    ans.first = max(opt1, max(opt2, opt3));
    ans.second = max(left.second, right.second) + 1;

    return ans;
}

int diameter2(Node* root)
{
    return diameterFast(root).first;
}

int main()
{   

    Node* root = NULL;
    root = buildTree(root);
    lvlOrderTraversal(root);
    
    int ans = diameter2(root);
    cout << endl;
    cout << "Max height of tree: " << ans << endl; 

    return 0;
}