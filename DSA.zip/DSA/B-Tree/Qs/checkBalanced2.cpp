#include<iostream>
#include<queue>
#include<utility>

using namespace std;

class Node
{
    public:
    int data;
    Node* left;
    Node* right;

    Node(int data)
    {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};

Node* buildTree(Node* root)
{
    cout << "Enter data: ";
    int data;
    cin >> data;

    if( data == -1 )
    {
        return NULL;
    }

    root = new Node(data);

    //Build left part
    cout << "Enter data for inserting in left of " << data << endl;
    root->left = buildTree(root->left);

    //Build right part
    cout << "Enter data for inserting in right of " << data << endl;
    root->right = buildTree(root->right);

    return root;

}

void lvlOrderTraversal(Node *root)
{
    queue<Node*> q;
    q.push(root);

    while(!q.empty())
    {
        Node *tmp = q.front();
        cout << tmp->data << " ";
        q.pop();

        if(tmp->left)
        {
            q.push(tmp->left);
        }

        if(tmp->right)
        {
            q.push(tmp->right);
        }
    }
}

pair<bool, int> ifBalancedFast(Node* root)
{
    if(root == NULL)
    {
        pair<bool, int> p = make_pair(true,0);
        return p;
    }
 
    pair<bool, int> left = ifBalancedFast(root->left);
    pair<bool, int> right = ifBalancedFast(root->right);

    bool leftAns = left.first;
    bool rightAns = right.first;
    bool diff = abs((left.second) - (right.second) <= 1);

    pair<bool, int> ans;
    ans.second = max(left.second, right.second) + 1;
    if(leftAns && rightAns && diff)
    {
        ans.first = true;
    }
    else
    {
        ans.first = false;
    }
    return ans;
}

bool ifBalanced(Node* root)
{
    return ifBalancedFast(root).first;
}

int main()
{   

    Node* root = NULL;
    root = buildTree(root);
    lvlOrderTraversal(root);

    bool ans = ifBalanced(root);
    cout << endl;
    cout << ans << endl;

    return 0;
}