#include<iostream>
#include<queue>

using namespace std;

class Node
{
    public:
    int data;
    Node* left;
    Node* right;

    Node(int data)
    {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};

Node* buildTree(Node* root)
{
    cout << "Enter data: ";
    int data;
    cin >> data;

    if( data == -1 )
    {
        return NULL;
    }

    root = new Node(data);

    //Build left part
    cout << "Enter data for inserting in left of " << data << endl;
    root->left = buildTree(root->left);

    //Build right part
    cout << "Enter data for inserting in right of " << data << endl;
    root->right = buildTree(root->right);

    return root;

}

void lvlOrderTraversal(Node *root)
{
    queue<Node*> q;
    q.push(root);

    while(!q.empty())
    {
        Node *tmp = q.front();
        cout << tmp->data << " ";
        q.pop();

        if(tmp->left)
        {
            q.push(tmp->left);
        }

        if(tmp->right)
        {
            q.push(tmp->right);
        }
    }
}

int findHeight(Node* root)
{
    if(root == NULL)
    {
        return 0;
    }
    int leftMax = findHeight(root->left);

    int rightMax = findHeight(root->right);

    
    int ans = max(leftMax, rightMax) + 1;
    return ans;
}

int main()
{   

    Node* root = NULL;
    root = buildTree(root);
    lvlOrderTraversal(root);
    //1 2 4 7 -1 -1 -1 5 -1 -1 3 -1 6 -1 8 -1 -1
    
    int ans = findHeight(root);
    cout << endl;
    cout << "Max height of tree: " << ans << endl; 

    //int dls = findDeepLeavesSum(root);
    //cout << "Deepest leaves sum: " << dls << endl;

    return 0;
}