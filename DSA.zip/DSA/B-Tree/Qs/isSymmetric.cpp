#include<iostream>
#include<queue>
#include<stack>
using namespace std;

class Node
{
    public:
    int data;
    Node* left;
    Node* right;

    Node(int data)
    {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};

Node* buildTree(Node* root)
{
    cout << "Enter data: ";
    int data;
    cin >> data;

    if( data == -1 )
    {
        return NULL;
    }

    root = new Node(data);

    //Build left part
    cout << "Enter data for inserting in left of " << data << endl;
    root->left = buildTree(root->left);

    //Build right part
    cout << "Enter data for inserting in right of " << data << endl;
    root->right = buildTree(root->right);

    return root;

}

void levelOrderTraversal(Node *root)
{
    queue<Node*> q;
    q.push(root);

    while(!q.empty())
    {
        Node *tmp = q.front();
        cout << tmp->data << " ";
        q.pop();

        if(tmp->left)
        {
            q.push(tmp->left);
        }
        
        if(tmp->right)
        {
            q.push(tmp->right);
        }
    }
}

bool isSymmetric(Node* root) 
{
    queue<Node*> q;
    stack<int> s1;
    stack<int> s2;

    //push root->left elements 
    q.push(root->left);
    while(!q.empty())
    {
        Node* tmp = q.front();
        //cout << tmp->data << endl;
        s1.push(tmp->data);
        q.pop();

        if(tmp->left != NULL)
        {
            q.push(tmp->left);
        }
        else
        {
            s1.push(-2);
        }
        if(tmp->right != NULL)
        {
            q.push(tmp->right);
        }
        else
        {
            s1.push(-3);
        }
    }

    //push root->right elements
    q.push(root->right);
    while(!q.empty())
    {
        Node* tmp = q.front();
        //cout << tmp->data << endl;
        s2.push(tmp->data);
        q.pop();

        if(tmp->right != NULL)
        {
            q.push(tmp->right);
        }
        else
        {
            s2.push(-2);
        }
        if(tmp->left != NULL)
        {
            q.push(tmp->left);
        }
        else
        {
            s2.push(-3);
        }
    }

    cout << "Stack 1: " << endl;
    while(!s1.empty())
    {
        int val = s1.top();
        cout << val << endl;
        s1.pop();
    }
    cout << endl;

    cout << "Stack 2: " << endl;
    while(!s2.empty())
    {
        int val = s2.top();
        cout << val << endl;
        s2.pop();
    }
    cout << endl;


    while((!s1.empty()) && (!s2.empty()))
    {
        int val1 = s1.top();
        int val2 = s2.top();
        
        if(val1 == val2)
        {
            s1.pop();
            s2.pop();
        }
        else
        {
            return false;
        }
    }
    return true;
}

int main()
{
    Node* root = NULL;
    root = buildTree(root);
    bool ans = isSymmetric(root);
    cout << ans << endl;
    return 0;
}