#include<iostream>
#include <queue>
#include <stack>
#include<vector>
using namespace std;

class Node
{
    public:
    int data;
    Node* left;
    Node* right;

    Node(int data)
    {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};
// 1 3 7 -1 -1 11 -1 -1 5 17 -1 -1 -1 
Node* buildTree(Node* root)
{
    cout << "Enter data: ";
    int data;
    cin >> data;

    if( data == -1 )
    {
        return NULL;
    }

    root = new Node(data);

    //Build left part
    cout << "Enter data for inserting in left of " << data << endl;
    root->left = buildTree(root->left);

    //Build right part
    cout << "Enter data for inserting in right of " << data << endl;
    root->right = buildTree(root->right);

    return root;

}

void levelOrderTraversal(Node *root)
{
    queue<Node*> q;
    q.push(root);

    while(!q.empty())
    {
        Node *tmp = q.front();
        cout << tmp->data << " ";
        q.pop();

        if(tmp->left)
        {
            q.push(tmp->left);
        }
        
        if(tmp->right)
        {
            q.push(tmp->right);
        }
    }
}

void preorderTraversal(Node *root)
{
    if(root == NULL)
    {
        return;
    }

    cout << root->data << " ";
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}

void postorderTraversal(Node *root)
{
    if(root == NULL)
    {
        return;
    }

    postorderTraversal(root->left);
    postorderTraversal(root->right);
    cout << root->data << " ";
}

void buildFromLvlorder(Node* &root)
{
    queue<Node*> q;
    cout << "Enter data for root: " << endl;
    int data;
    cin >> data;
    root = new Node(data);
    q.push(root);

    while(!q.empty())
    {
        Node *tmp = q.front();
        q.pop();   

        cout << "Enter data for left of " << tmp->data << endl;
        int lData;
        cin >> lData;

        if(lData!=-1)
        {
            tmp->left = new Node(lData);
            q.push(tmp->left);
        }

        cout << "Enter data for right of " << tmp->data << endl;
        int rData;
        cin >> rData;

        if(rData!=-1)
        {
            tmp->right = new Node(rData);
            q.push(tmp->right);
        }
    }

}

bool sameTree(Node* p, Node* q) //1 2 -1 -1 3 -1 -1 
{
    bool ans = true;

    if(p == NULL && q == NULL)
        return true;

    if((p == NULL && q != NULL) || (p != NULL && q == NULL))
        return false;

    if(p->data != q->data)
        return false;

    ans = sameTree(p->left, q->left);
    if(ans == false)
        return ans;

    ans = sameTree(p->right, q->right);

    return ans;
}

Node* buildnewTree(Node* root, int val)
{
    if(root == NULL)
    {
        return new Node(val);
    }

    if(val < root->data)
    {
        root->left = buildnewTree(root->left, val);
    }
    else
    {
        root->right = buildnewTree(root->right, val);
    }

    return root;
}

Node* sortedArrToBST(vector<int> &arr)
{
    int halfSize = (arr.size()/2);
    Node* root = new Node(arr[halfSize]);
    
    //left part
    for(int i=0; i<halfSize; i++)
    {
        root = buildnewTree(root->left, arr[i]);
    }

    //right part
    for(int i=halfSize; i<arr.size(); i++)
    {
        root = buildnewTree(root->right, arr[i]);
    }

    return root;
}

int findHeight(Node* root)
{
    if(root == NULL)
    {
        return 0;
    }
    int leftMax = findHeight(root->left);

    int rightMax = findHeight(root->right);

    
    int ans = max(leftMax, rightMax) + 1;
    return ans;
}

int diameter1(Node* root)
{
    if(root == NULL)
        return 0;

    int opt1 = diameter1(root->left);
    int opt2 = diameter1(root->right);
    int opt3 = findHeight(root->left) + findHeight(root->right) + 1;

    int ans = max(opt1, max(opt2, opt3));
    return ans;
}

int main()//1 2 3 -1 -1 4 -1 -1 2 4 -1 -1 3 -1 -1
// 1 2 -1 3 -1 -1 2 -1 3 -1 -1
{
    Node* root = NULL;
    // //buildFromLvlorder(root);

    root = buildTree(root);

    cout << "lvlOrderTraversal: ";
    levelOrderTraversal(root);
    cout << endl;
    cout << "Diameter of tree: ";
    int d = diameter1(root);
    cout << d << endl;
    // /*
    // cout << "inorderTraversal: ";
    // inorderTraversal(root);ṇ
    // cout << endl;

    // cout << "preorderTraversal: ";
    // preorderTraversal(root);
    // cout << endl;

    // cout << "postorderTraversal: ";
    // postorderTraversal(root);
    // cout << endl;*/

    // bool ans = isSymmetric(root);
    // if(ans)
    //     cout << ans << endl;

    // cout << "P: " << endl;
    // Node* p = NULL;
    // p = buildTree(p);
    // cout << endl;
    // cout << "P - lvlOrderTraversal: ";
    // levelOrderTraversal(p);
    // cout << endl;

    // cout << "Q: " << endl;
    // Node* q = NULL;
    // q = buildTree(q);
    // cout << endl;
    // cout << "Q - lvlOrderTraversal: ";
    // levelOrderTraversal(q);
    // cout << endl;

    // bool ans = sameTree(p, q);
    // cout << "Ans: " << ans << endl;

    // vector<int> arr = {-10, -3, 0, 5, 9};

    // Node* root = sortedArrToBST(arr);

    // cout << "lvlOrderTraversal: ";
    // levelOrderTraversal(root);

    

    return 0;
}

